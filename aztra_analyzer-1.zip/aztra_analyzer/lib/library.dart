import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'codec.dart';
import 'dsp.dart';
import 'music_store.dart';
import 'settings.dart';
import 'analyzer.dart';
import 'background.dart';
import 'audio_analysis_models.dart';
import 'store.dart';

const _audioExtensions = {
  '.flac', '.mp3', '.m4a', '.aac', '.opus', '.ogg', '.wav', '.wma', '.wv',
  '.ape', '.tta', '.aif', '.aiff', '.ac3', '.eac3', '.mka',
};

bool isAudioPath(String path) {
  final lower = path.toLowerCase();
  return _audioExtensions.any(lower.endsWith);
}

enum ItemState { waiting, running, done, error }

class Item {
  Item({
    required this.path,
    required this.size,
    required this.mtime,
    this.temp = false,
  });

  final String path;
  final int size;
  final int mtime;

  /// Archivo suelto (copia temporal): no se guarda en la biblioteca.
  final bool temp;

  ItemState state = ItemState.waiting;
  AudioAnalysisData? data;
  String? error;

  String get name => path.split('/').last;
  String get cacheKey => SpectrogramCache.keyFor(path, size, mtime);
}

enum SortKey { name, dr, lufs, cutoff }

enum LibFilter { all, suspicious, compressed }

const _losslessCodecs = {'flac', 'alac', 'wavpack', 'ape', 'tta'};

/// Marca canciones lossless cuyo espectro sugiere un origen con perdida.
String? suspicionOf(AudioAnalysisData d) {
  final codec = d.codec.toLowerCase();
  final lossless = _losslessCodecs.contains(codec) || codec.startsWith('pcm_');
  if (!lossless) return null;
  final cutoff = d.spectralCutoffHz;
  if (cutoff == null) return null;
  if (d.sampleRate > 48000 && cutoff < 23000) {
    return 'Posible upsample (corte en ${(cutoff / 1000).toStringAsFixed(1)} kHz)';
  }
  if (cutoff < 19000) {
    return 'Posible transcode de MP3/AAC (corte en ${(cutoff / 1000).toStringAsFixed(1)} kHz)';
  }
  return null;
}

bool isCompressed(AudioAnalysisData d) => d.dynamicRange < 8;

class LibrarySummary {
  const LibrarySummary({
    required this.analyzed,
    required this.avgDr,
    required this.avgLufs,
    required this.suspicious,
  });
  final int analyzed;
  final double? avgDr;
  final double? avgLufs;
  final int suspicious;
}

class LibraryController extends ChangeNotifier {
  LibraryController(this.settings);

  final AppSettings settings;
  final Analyzer analyzer = Analyzer();
  final Map<String, Item> _items = {};
  final List<Item> _queue = [];
  final Map<String, MusicAnalysis> _music = {};
  int _active = 0;
  bool _saving = false;

  bool running = false;
  bool scanning = false;
  int runTotal = 0;
  int runDone = 0;
  String? currentName;
  bool _stop = false;
  int _unsaved = 0;

  Future<void> init() async {
    final stored = await ResultsStore.load();
    for (final e in stored.entries) {
      _items[e.key] = Item(
        path: e.key,
        size: e.value.size,
        mtime: e.value.mtime,
      )
        ..data = e.value.data
        ..state = ItemState.done;
    }
    _music.addAll(await MusicStore.load());
    try {
      await FilePicker.platform.clearTemporaryFiles();
    } catch (_) {}
    notifyListeners();
  }

  /// BPM, tonalidad y balance ya calculados de esta cancion (o null).
  MusicAnalysis? musicFor(Item item) => _music[item.cacheKey];

  /// Calcula (o recupera de la cache) el analisis musical de una cancion.
  Future<MusicAnalysis> computeMusic(Item item, {bool force = false}) async {
    final cached = _music[item.cacheKey];
    if (cached != null && !force) return cached;
    final m = await analyzer.analyzeMusic(item.path, item.data!.duration);
    _music[item.cacheKey] = m;
    await MusicStore.save(_music);
    notifyListeners();
    return m;
  }

  int get totalItems => _items.length;

  /// Canciones ya analizadas (para duplicados y comparar).
  List<Item> get analyzedItems => _items.values
      .where((i) => i.state == ItemState.done && i.data != null)
      .toList();

  /// Agrega archivos a la cola. Devuelve cuantos se van a analizar.
  Future<int> addPaths(Iterable<String> paths, {bool temp = false}) async {
    var added = 0;
    for (final p in paths) {
      if (!isAudioPath(p)) continue;
      try {
        final st = await File(p).stat();
        if (st.type != FileSystemEntityType.file) continue;
        final mtime = st.modified.millisecondsSinceEpoch;
        final existing = _items[p];
        if (existing != null) {
          if (existing.state == ItemState.waiting ||
              existing.state == ItemState.running) {
            continue;
          }
          if (existing.state == ItemState.done &&
              existing.size == st.size &&
              existing.mtime == mtime) {
            continue;
          }
        }
        final item = Item(path: p, size: st.size, mtime: mtime, temp: temp);
        _items[p] = item;
        _queue.add(item);
        added++;
      } catch (_) {}
    }
    notifyListeners();
    if (added > 0) unawaited(_runQueue());
    return added;
  }

  /// Busca audio dentro de una carpeta (con subcarpetas).
  Future<({int found, int added})> addFolder(String dir) async {
    scanning = true;
    notifyListeners();
    final found = <String>[];
    try {
      final stream = Directory(
        dir,
      ).list(recursive: true, followLinks: false).handleError((_) {});
      await for (final e in stream) {
        if (e is File && isAudioPath(e.path)) found.add(e.path);
      }
    } catch (_) {}
    scanning = false;
    final added = await addPaths(found);
    return (found: found.length, added: added);
  }

  Future<void> _runQueue() async {
    if (running) return;
    running = true;
    _stop = false;
    _active = 0;
    runTotal = _queue.length;
    runDone = 0;
    var cancelled = false;
    var okCount = 0;
    var errCount = 0;
    await BackgroundService.start(
      title: 'Analizando canciones…',
      text: '',
      progress: 0,
      max: runTotal,
    );
    notifyListeners();

    Future<void> worker() async {
      while (!_stop && _queue.isNotEmpty) {
        final item = _queue.removeAt(0);
        item.state = ItemState.running;
        currentName = item.name;
        _active++;
        runTotal = runDone + _queue.length + _active;
        notifyListeners();
        unawaited(
          BackgroundService.update(
            title: 'Analizando ${runDone + 1} de $runTotal',
            text: item.name,
            progress: runDone,
            max: runTotal,
          ),
        );
        try {
          final d = await analyzer.analyze(item.path);
          item.data = d;
          item.error = null;
          item.state = ItemState.done;
          okCount++;
          if (!item.temp) _unsaved++;
        } catch (e) {
          if (_stop) {
            if (item.data == null) {
              _items.remove(item.path);
            } else {
              item.state = ItemState.done;
            }
            _active--;
            return;
          }
          item.error = e.toString().replaceFirst('Exception: ', '');
          item.state = ItemState.error;
          errCount++;
        }
        _active--;
        runDone++;
        notifyListeners();
        if (_unsaved >= 25) await _save();
      }
    }

    try {
      final threads = settings.analysisThreads.clamp(1, 3).toInt();
      do {
        await Future.wait(List.generate(threads, (_) => worker()));
      } while (!_stop && _queue.isNotEmpty);
      if (_stop) {
        cancelled = true;
        for (final item in _queue) {
          if (item.data == null) _items.remove(item.path);
        }
        _queue.clear();
      }
    } finally {
      running = false;
      currentName = null;
      _active = 0;
      await _save();
      if (cancelled) {
        await BackgroundService.stop();
      } else {
        await BackgroundService.finish(
          title: 'Análisis terminado',
          text:
              '${okCount == 1 ? '1 canción analizada' : '$okCount canciones analizadas'}'
              '${errCount > 0 ? ' · $errCount con error' : ''}',
        );
      }
      notifyListeners();
    }
  }

  Future<void> stop() async {
    _stop = true;
    notifyListeners();
    await analyzer.cancelAll();
  }

  /// Reanaliza una cancion ahora mismo (sin pasar por la cola).
  Future<bool> reanalyze(Item item) async {
    final previous = item.state;
    item.state = ItemState.running;
    notifyListeners();
    try {
      item.data = await analyzer.analyze(item.path);
      item.error = null;
      item.state = ItemState.done;
      if (!item.temp) await _save();
      notifyListeners();
      return true;
    } catch (e) {
      item.error = e.toString().replaceFirst('Exception: ', '');
      item.state = item.data != null ? ItemState.done : previous;
      notifyListeners();
      return false;
    }
  }

  /// Reintenta una cancion con error.
  Future<void> retry(Item item) async {
    if (item.state != ItemState.error) return;
    item.state = ItemState.waiting;
    _queue.add(item);
    notifyListeners();
    unawaited(_runQueue());
  }

  Future<void> _save() async {
    if (_saving) return;
    _saving = true;
    try {
      await _saveNow();
    } finally {
      _saving = false;
    }
  }

  Future<void> _saveNow() async {
    final map = <String, StoredResult>{};
    for (final i in _items.values) {
      if (i.temp || i.state != ItemState.done || i.data == null) continue;
      map[i.path] = StoredResult(data: i.data!, size: i.size, mtime: i.mtime);
    }
    _unsaved = 0;
    await ResultsStore.save(map);
  }

  Future<void> clearAll() async {
    if (running) return;
    _items.clear();
    _music.clear();
    await ResultsStore.clear();
    await MusicStore.clear();
    notifyListeners();
  }

  LibrarySummary summary() {
    var n = 0;
    var drSum = 0.0;
    var lufsSum = 0.0;
    var lufsN = 0;
    var sus = 0;
    for (final i in _items.values) {
      final d = i.data;
      if (i.state != ItemState.done || d == null) continue;
      n++;
      drSum += d.dynamicRange;
      if (d.integratedLufs != null) {
        lufsSum += d.integratedLufs!;
        lufsN++;
      }
      if (suspicionOf(d) != null) sus++;
    }
    return LibrarySummary(
      analyzed: n,
      avgDr: n > 0 ? drSum / n : null,
      avgLufs: lufsN > 0 ? lufsSum / lufsN : null,
      suspicious: sus,
    );
  }

  /// Cuantas canciones analizadas hay de cada formato (FLAC, MP3, WAV, Otros).
  Map<String, int> formatCounts() {
    final counts = <String, int>{};
    for (final i in _items.values) {
      final d = i.data;
      if (i.state != ItemState.done || d == null) continue;
      final g = formatGroup(d);
      counts[g] = (counts[g] ?? 0) + 1;
    }
    return counts;
  }

  List<Item> view({
    String query = '',
    LibFilter filter = LibFilter.all,
    String? format,
    SortKey sort = SortKey.name,
    bool ascending = true,
  }) {
    final q = query.trim().toLowerCase();
    final list = _items.values.where((i) {
      if (q.isNotEmpty && !i.name.toLowerCase().contains(q)) return false;
      final d = i.data;
      if (format != null) {
        if (d == null || formatGroup(d) != format) return false;
      }
      if (filter == LibFilter.all) return true;
      if (d == null) return false;
      if (filter == LibFilter.suspicious) return suspicionOf(d) != null;
      return isCompressed(d);
    }).toList();

    int cmpNum(double? a, double? b) {
      if (a == null && b == null) return 0;
      if (a == null) return 1; // sin dato siempre al final
      if (b == null) return -1;
      return ascending ? a.compareTo(b) : b.compareTo(a);
    }

    list.sort((a, b) {
      switch (sort) {
        case SortKey.name:
          final c = a.name.toLowerCase().compareTo(b.name.toLowerCase());
          return ascending ? c : -c;
        case SortKey.dr:
          return cmpNum(a.data?.dynamicRange, b.data?.dynamicRange);
        case SortKey.lufs:
          return cmpNum(a.data?.integratedLufs, b.data?.integratedLufs);
        case SortKey.cutoff:
          return cmpNum(a.data?.spectralCutoffHz, b.data?.spectralCutoffHz);
      }
    });
    return list;
  }

  static String _csv(Object? v) {
    final s = v?.toString() ?? '';
    if (s.contains(',') || s.contains('"') || s.contains('\n')) {
      return '"${s.replaceAll('"', '""')}"';
    }
    return s;
  }

  /// Escribe un CSV con todos los resultados y devuelve su ruta.
  Future<String?> exportCsv() async {
    final rows = _items.values
        .where((i) => i.state == ItemState.done && i.data != null)
        .toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    if (rows.isEmpty) return null;
    final b = StringBuffer('\uFEFF');
    b.writeln(
      'archivo,ruta,codec,frecuencia_hz,bits,bitrate_kbps,canales,duracion_s,'
      'tamano_bytes,rango_dinamico_db,pico_db,rms_db,lufs,pico_real_dbtp,'
      'recorte_muestras,corte_espectral_hz,aviso,bpm,tonalidad',
    );
    for (final i in rows) {
      final d = i.data!;
      b.writeln(
        [
          i.name,
          i.path,
          codecLabel(d),
          d.sampleRate,
          d.bitDepth,
          (d.bitrate / 1000).round(),
          d.channels,
          d.duration.toStringAsFixed(1),
          d.fileSize,
          d.dynamicRange.toStringAsFixed(2),
          d.peakAmplitude.toStringAsFixed(2),
          d.rmsLevel.toStringAsFixed(2),
          d.integratedLufs?.toStringAsFixed(1),
          d.truePeakDb?.toStringAsFixed(2),
          d.clippingSamples,
          d.spectralCutoffHz?.toStringAsFixed(0),
          suspicionOf(d),
          musicFor(i)?.bpm?.toStringAsFixed(1),
          musicFor(i)?.keyLabel,
        ].map(_csv).join(','),
      );
    }
    final tmp = await getTemporaryDirectory();
    final now = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    final stamp = '${now.year}${two(now.month)}${two(now.day)}';
    final f = File('${tmp.path}/aztra_analyzer_$stamp.csv');
    await f.writeAsString(b.toString());
    return f.path;
  }
}
