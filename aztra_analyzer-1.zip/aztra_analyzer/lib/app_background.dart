import 'package:flutter/material.dart';

import 'settings.dart';

/// Deja las preferencias a la mano de cualquier pantalla.
class SettingsScope extends InheritedNotifier<AppSettings> {
  const SettingsScope({
    super.key,
    required AppSettings settings,
    required super.child,
  }) : super(notifier: settings);

  static AppSettings of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<SettingsScope>();
    assert(scope != null, 'Falta SettingsScope arriba en el arbol');
    return scope!.notifier!;
  }
}

/// Dibuja la imagen de fondo (si hay una) detras de la pantalla. Cada pantalla
/// se envuelve con esto, asi las transiciones siguen viendose bien.
class AppBackground extends StatelessWidget {
  const AppBackground({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final settings = SettingsScope.of(context);
    final file = settings.backgroundImage;
    if (file == null) return child;
    return Stack(
      fit: StackFit.expand,
      children: [
        const ColoredBox(color: Colors.black),
        Image.file(
          file,
          key: ValueKey(file.path),
          fit: BoxFit.cover,
          cacheWidth: 1440,
          gaplessPlayback: true,
          errorBuilder: (context, error, stack) => const SizedBox.shrink(),
        ),
        ColoredBox(
          color: Colors.black.withValues(alpha: settings.backgroundDim),
        ),
        child,
      ],
    );
  }
}

/// Como un Scaffold, pero con la imagen de fondo (si hay) detras.
class AppScaffold extends StatelessWidget {
  const AppScaffold({
    super.key,
    this.appBar,
    this.body,
    this.floatingActionButton,
  });

  final PreferredSizeWidget? appBar;
  final Widget? body;
  final Widget? floatingActionButton;

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: Scaffold(
        appBar: appBar,
        body: body,
        floatingActionButton: floatingActionButton,
      ),
    );
  }
}
