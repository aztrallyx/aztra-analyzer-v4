import 'package:flutter/material.dart';

import 'dsp.dart';
import 'library.dart';

/// Tarjeta de la pantalla de detalle: BPM y tonalidad (se calculan al tocar).
class MusicCard extends StatefulWidget {
  const MusicCard({super.key, required this.item, required this.controller});

  final Item item;
  final LibraryController controller;

  @override
  State<MusicCard> createState() => _MusicCardState();
}

class _MusicCardState extends State<MusicCard> {
  bool _busy = false;
  String? _error;

  Future<void> _run({bool force = false}) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.controller.computeMusic(widget.item, force: force);
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
    }
    if (!mounted) return;
    setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final m = widget.controller.musicFor(widget.item);

    Widget line(String label, String value, String? extra) => Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text.rich(
        TextSpan(
          children: [
            TextSpan(
              text: '$label: ',
              style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
            ),
            TextSpan(
              text: value,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            if (extra != null)
              TextSpan(
                text: '  $extra',
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
              ),
          ],
        ),
      ),
    );

    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      color: cs.surfaceContainer,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: cs.outlineVariant.withValues(alpha: 0.5)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Ritmo y tonalidad',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                ),
                if (m != null && !_busy)
                  IconButton(
                    icon: const Icon(Icons.refresh, size: 20),
                    tooltip: 'Volver a calcular',
                    visualDensity: VisualDensity.compact,
                    color: cs.onSurfaceVariant,
                    onPressed: () => _run(force: true),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            if (_busy) ...[
              const LinearProgressIndicator(minHeight: 2),
              const SizedBox(height: 8),
              Text(
                'Analizando… tarda unos segundos.',
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
              ),
            ] else if (m == null) ...[
              FilledButton.tonal(
                onPressed: _run,
                child: const Text('Detectar BPM y tonalidad'),
              ),
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!, style: TextStyle(color: cs.error, fontSize: 12)),
              ],
            ] else ...[
              if (m.bpm != null)
                line(
                  'BPM',
                  formatBpm(m.bpm!),
                  m.altBpm == null
                      ? 'confianza ${m.bpmConfidence}'
                      : 'o ${formatBpm(m.altBpm!)} · confianza ${m.bpmConfidence}',
                )
              else
                line('BPM', 'no se pudo estimar', null),
              if (m.keyLabel != null)
                line(
                  'Tonalidad',
                  m.keyLabel!,
                  'relativa: ${m.relativeLabel} · confianza ${m.keyConfidence}',
                )
              else
                line('Tonalidad', 'no se pudo estimar', null),
              Text(
                'Es una estimación sobre hasta 4 minutos de la canción. En música '
                'real puede fallar: el tempo puede salir al doble o a la mitad, y '
                'la tonalidad puede confundirse con su relativa.',
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 11),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
