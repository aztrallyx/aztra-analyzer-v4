import 'audio_analysis_models.dart';

/// Nombre bonito del formato. FFmpeg reporta los WAV como "PCM_S16LE",
/// "PCM_S24LE", etc.; aqui se muestran como WAV (o AIFF) segun la extension.
/// Solo cambia lo que se ve: el analisis no se toca.
String codecLabel(AudioAnalysisData d) {
  final c = d.codec.toLowerCase();
  if (c.startsWith('pcm_')) {
    final p = d.filePath.toLowerCase();
    if (p.endsWith('.wav') || p.endsWith('.wave') || p.endsWith('.w64') || p.endsWith('.bwf')) {
      return 'WAV';
    }
    if (p.endsWith('.aif') || p.endsWith('.aiff') || p.endsWith('.aifc')) {
      return 'AIFF';
    }
    return 'PCM';
  }
  switch (c) {
    case 'flac':
      return 'FLAC';
    case 'mp3':
      return 'MP3';
    case 'aac':
      return 'AAC';
    case 'alac':
      return 'ALAC';
    case 'vorbis':
      return 'OGG Vorbis';
    case 'opus':
      return 'Opus';
    case 'wavpack':
      return 'WavPack';
    case 'ape':
      return 'APE';
    case 'tta':
      return 'TTA';
    case 'wmav1':
    case 'wmav2':
    case 'wmapro':
    case 'wmalossless':
      return 'WMA';
  }
  return d.codec.isEmpty ? '—' : d.codec;
}

/// Grupo para el filtro rapido: FLAC, MP3, WAV u Otros.
String formatGroup(AudioAnalysisData d) {
  final l = codecLabel(d);
  if (l == 'FLAC' || l == 'MP3' || l == 'WAV') return l;
  return 'Otros';
}

const kFormatGroups = ['FLAC', 'MP3', 'WAV', 'Otros'];
