// Analisis musical (BPM, tonalidad, balance de frecuencias) en Dart puro.
// Los algoritmos se validaron primero en Python con senales de prueba.
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

/// FFT iterativa radix-2 (complejo, hacia adelante).
class Fft {
  Fft(this.n)
    : _cos = Float64List(n ~/ 2),
      _sin = Float64List(n ~/ 2),
      _rev = Int32List(n) {
    var bits = 0;
    while ((1 << bits) < n) {
      bits++;
    }
    for (var i = 0; i < n; i++) {
      var x = i;
      var r = 0;
      for (var b = 0; b < bits; b++) {
        r = (r << 1) | (x & 1);
        x >>= 1;
      }
      _rev[i] = r;
    }
    for (var k = 0; k < n ~/ 2; k++) {
      _cos[k] = math.cos(2 * math.pi * k / n);
      _sin[k] = math.sin(2 * math.pi * k / n);
    }
  }

  final int n;
  final Float64List _cos;
  final Float64List _sin;
  final Int32List _rev;

  void transform(Float64List re, Float64List im) {
    for (var i = 0; i < n; i++) {
      final j = _rev[i];
      if (j > i) {
        final tr = re[i];
        re[i] = re[j];
        re[j] = tr;
        final ti = im[i];
        im[i] = im[j];
        im[j] = ti;
      }
    }
    for (var size = 2; size <= n; size <<= 1) {
      final half = size >> 1;
      final step = n ~/ size;
      for (var start = 0; start < n; start += size) {
        for (var k = 0; k < half; k++) {
          final wr = _cos[k * step];
          final wi = -_sin[k * step];
          final a = start + k;
          final b = a + half;
          final tr = re[b] * wr - im[b] * wi;
          final ti = re[b] * wi + im[b] * wr;
          re[b] = re[a] - tr;
          im[b] = im[a] - ti;
          re[a] += tr;
          im[a] += ti;
        }
      }
    }
  }
}

const List<String> kNoteNames = [
  'C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B',
];

const List<String> kBandNames = [
  'Sub',
  'Bajos',
  'Bajo-medios',
  'Medios',
  'Medio-altos',
  'Altos',
  'Aire',
];

const List<String> kBandRanges = [
  '20–60 Hz',
  '60–250 Hz',
  '250–500 Hz',
  '500 Hz–2 kHz',
  '2–4 kHz',
  '4–8 kHz',
  '8–20 kHz',
];

/// Indice de la banda que se usa como referencia al comparar (los medios).
const int kBandAnchor = 3;

class MusicAnalysis {
  const MusicAnalysis({
    required this.bpm,
    required this.bpmPeak,
    required this.keyRoot,
    required this.keyMinor,
    required this.keyCorr,
    required this.bandsDb,
  });

  final double? bpm;

  /// Que tan marcado es el pico del tempo (ruido ~1.3, musica ritmica 3 a 8).
  final double bpmPeak;
  final int? keyRoot;
  final bool keyMinor;

  /// Correlacion de la tonalidad elegida (ruido ~0.4, musica clara > 0.75).
  final double keyCorr;

  /// Energia de cada banda respecto al total, en dB (7 bandas).
  final List<double>? bandsDb;

  String? get keyLabel => keyRoot == null
      ? null
      : '${kNoteNames[keyRoot!]} ${keyMinor ? 'menor' : 'mayor'}';

  /// Tonalidad relativa (la que comparte las mismas notas).
  String? get relativeLabel {
    final r = keyRoot;
    if (r == null) return null;
    return keyMinor
        ? '${kNoteNames[(r + 3) % 12]} mayor'
        : '${kNoteNames[(r + 9) % 12]} menor';
  }

  /// Tempo alterno: el doble si es lento, la mitad si es rapido.
  double? get altBpm {
    final b = bpm;
    if (b == null) return null;
    if (b < 100) return b * 2 <= 200 ? b * 2 : null;
    return b / 2;
  }

  String get bpmConfidence =>
      bpmPeak >= 4.0 ? 'alta' : (bpmPeak >= 2.5 ? 'media' : 'baja');

  String get keyConfidence =>
      keyCorr >= 0.75 ? 'alta' : (keyCorr >= 0.6 ? 'media' : 'baja');

  Map<String, dynamic> toJson() => {
    'bpm': bpm,
    'bpmPeak': bpmPeak,
    'keyRoot': keyRoot,
    'keyMinor': keyMinor,
    'keyCorr': keyCorr,
    'bandsDb': bandsDb,
  };

  factory MusicAnalysis.fromJson(Map<String, dynamic> j) {
    final bands = j['bandsDb'];
    return MusicAnalysis(
      bpm: (j['bpm'] as num?)?.toDouble(),
      bpmPeak: (j['bpmPeak'] as num?)?.toDouble() ?? 0,
      keyRoot: j['keyRoot'] as int?,
      keyMinor: j['keyMinor'] as bool? ?? false,
      keyCorr: (j['keyCorr'] as num?)?.toDouble() ?? 0,
      bandsDb: bands is List
          ? bands.map((e) => (e as num).toDouble()).toList()
          : null,
    );
  }
}

String formatBpm(double bpm) =>
    bpm.toStringAsFixed((bpm - bpm.roundToDouble()).abs() < 0.05 ? 0 : 1);

Float64List _hann(int n) {
  final w = Float64List(n);
  for (var i = 0; i < n; i++) {
    w[i] = 0.5 - 0.5 * math.cos(2 * math.pi * i / n);
  }
  return w;
}

/// 44.1 kHz -> 11.025 kHz (promedio de 4 muestras), a rango -1..1.
Float64List _downsample4(Int16List s) {
  final n = s.length ~/ 4;
  final out = Float64List(n);
  for (var i = 0; i < n; i++) {
    final j = i * 4;
    out[i] = (s[j] + s[j + 1] + s[j + 2] + s[j + 3]) / (4 * 32768.0);
  }
  return out;
}

double _interp(Float64List o, double pos) {
  final i = pos.floor();
  final f = pos - i;
  if (i < 0 || i + 1 >= o.length) return 0.0;
  return o[i] * (1 - f) + o[i + 1] * f;
}

/// Mejor alineacion de un tren de pulsos con periodo [lag] (en cuadros).
double _pulseScore(Float64List o, double lag) {
  final n = o.length;
  var best = 0.0;
  final steps = math.max(4, lag.floor());
  for (var p = 0; p < steps; p++) {
    final phi = lag * p / steps;
    var tot = 0.0;
    var cnt = 0;
    var pos = phi;
    while (pos < n - 1) {
      tot += _interp(o, pos) + 0.35 * _interp(o, pos + lag / 2.0);
      cnt++;
      pos += lag;
    }
    if (cnt > 0) {
      final v = tot / cnt;
      if (v > best) best = v;
    }
  }
  return best;
}

class _BpmResult {
  const _BpmResult(this.bpm, this.peak);
  final double bpm;
  final double peak;
}

_BpmResult? _detectBpm(Float64List full) {
  const sr = 11025.0;
  const nfft = 1024;
  const hop = 256;
  // Para el tempo bastan los primeros 150 s (ahorra tiempo en canciones largas).
  final maxSamples = (150 * sr).floor() + nfft;
  final x = full.length > maxSamples
      ? Float64List.sublistView(full, 0, maxSamples)
      : full;
  final nframes = (x.length - nfft) ~/ hop + 1;
  if (nframes < 200) return null;
  final fft = Fft(nfft);
  final win = _hann(nfft);
  final kmax = (5000.0 / sr * nfft).floor();
  final re = Float64List(nfft);
  final im = Float64List(nfft);
  final prev = Float64List(kmax);
  final cur = Float64List(kmax);
  final flux = Float64List(nframes);

  for (var t = 0; t < nframes; t++) {
    final off = t * hop;
    for (var i = 0; i < nfft; i++) {
      re[i] = x[off + i] * win[i];
      im[i] = 0.0;
    }
    fft.transform(re, im);
    var f = 0.0;
    for (var k = 0; k < kmax; k++) {
      final l = math.log(1.0 + math.sqrt(re[k] * re[k] + im[k] * im[k]));
      cur[k] = l;
      if (t > 0) {
        final d = l - prev[k];
        if (d > 0) f += d;
      }
    }
    flux[t] = f;
    prev.setRange(0, kmax, cur);
  }

  // Quitar la media movil y rectificar.
  final cs = Float64List(nframes + 1);
  for (var i = 0; i < nframes; i++) {
    cs[i + 1] = cs[i] + flux[i];
  }
  final fps = sr / hop;
  final limit = math.min(nframes, (150 * fps).floor());
  final o = Float64List(limit);
  for (var t = 0; t < limit; t++) {
    final a = math.max(0, t - 16);
    final b = math.min(nframes, t + 17);
    final m = (cs[b] - cs[a]) / (b - a);
    final v = flux[t] - m;
    o[t] = v > 0 ? v : 0.0;
  }

  final scores = <double>[];
  final bpms = <double>[];
  var bpm = 60.0;
  while (bpm <= 200.0) {
    final lag = fps * 60.0 / bpm;
    final sc = _pulseScore(o, lag);
    double prior;
    if (bpm < 75) {
      final z = math.log(bpm / 75.0) / math.ln2 / 0.35;
      prior = math.exp(-0.5 * z * z);
    } else if (bpm > 165) {
      final z = math.log(bpm / 165.0) / math.ln2 / 0.35;
      prior = math.exp(-0.5 * z * z);
    } else {
      prior = 1.0;
    }
    scores.add(sc * prior);
    bpms.add(bpm);
    bpm += 0.5;
  }

  var bi = 0;
  var sum = 0.0;
  for (var i = 0; i < scores.length; i++) {
    sum += scores[i];
    if (scores[i] > scores[bi]) bi = i;
  }
  final mean = sum / scores.length;
  var best = bpms[bi];
  final peak = scores[bi] / (mean + 1e-12);

  // Desempate de octava: si el doble de tempo puntua casi igual se prefiere
  // el rapido (un tempo lento siempre se alinea bien con los golpes fuertes).
  if (best * 2.0 <= 180.0) {
    final i2 = ((best * 2.0 - 60.0) / 0.5).round();
    if (i2 >= 0 && i2 < scores.length && scores[i2] >= 0.85 * scores[bi]) {
      bi = i2;
      best = bpms[i2];
    }
  }

  // Refinamiento fino alrededor del pico (paso 0.1).
  var fineScore = -1.0;
  var fineBpm = best;
  var b = best - 0.6;
  while (b <= best + 0.6) {
    final lag = fps * 60.0 / b;
    final sc = _pulseScore(o, lag);
    if (sc > fineScore) {
      fineScore = sc;
      fineBpm = b;
    }
    b += 0.1;
  }
  return _BpmResult(fineBpm, peak);
}

const List<double> _majorProfile = [
  6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88,
];
const List<double> _minorProfile = [
  6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17,
];

double _pearson(List<double> a, List<double> b) {
  var ma = 0.0;
  var mb = 0.0;
  for (var i = 0; i < a.length; i++) {
    ma += a[i];
    mb += b[i];
  }
  ma /= a.length;
  mb /= b.length;
  var cov = 0.0;
  var da = 0.0;
  var db = 0.0;
  for (var i = 0; i < a.length; i++) {
    final x = a[i] - ma;
    final y = b[i] - mb;
    cov += x * y;
    da += x * x;
    db += y * y;
  }
  final den = math.sqrt(da * db);
  return den > 1e-12 ? cov / den : 0.0;
}

class _KeyResult {
  const _KeyResult(this.root, this.minor, this.corr);
  final int root;
  final bool minor;
  final double corr;
}

_KeyResult? _detectKey(Float64List x) {
  const sr = 11025.0;
  const nfft = 4096;
  const hop = 2048;
  final nframes = (x.length - nfft) ~/ hop + 1;
  if (nframes < 8) return null;
  final fft = Fft(nfft);
  final win = _hann(nfft);
  final half = nfft ~/ 2;

  // Clase de nota (0..11) de cada bin; -1 si queda fuera de 65 Hz a 2.1 kHz.
  final pc = Int32List(half + 1);
  for (var k = 0; k <= half; k++) {
    pc[k] = -1;
  }
  for (var k = 1; k <= half; k++) {
    final f = k * sr / nfft;
    if (f >= 65.0 && f <= 2100.0) {
      final midi = (12 * (math.log(f / 440.0) / math.ln2) + 69).round();
      pc[k] = midi % 12;
    }
  }

  final re = Float64List(nfft);
  final im = Float64List(nfft);
  final chroma = List<double>.filled(12, 0.0);
  final frame = List<double>.filled(12, 0.0);
  for (var t = 0; t < nframes; t++) {
    final off = t * hop;
    for (var i = 0; i < nfft; i++) {
      re[i] = x[off + i] * win[i];
      im[i] = 0.0;
    }
    fft.transform(re, im);
    for (var i = 0; i < 12; i++) {
      frame[i] = 0.0;
    }
    for (var k = 1; k <= half; k++) {
      final c = pc[k];
      if (c >= 0) frame[c] += math.sqrt(re[k] * re[k] + im[k] * im[k]);
    }
    var s = 0.0;
    for (var i = 0; i < 12; i++) {
      s += frame[i];
    }
    if (s < 1e-6) continue;
    for (var i = 0; i < 12; i++) {
      chroma[i] += frame[i] / s;
    }
  }
  var total = 0.0;
  for (final v in chroma) {
    total += v;
  }
  if (total <= 0) return null;

  var bestCorr = -2.0;
  var bestRoot = 0;
  var bestMinor = false;
  for (var r = 0; r < 12; r++) {
    final rotMaj = List<double>.generate(12, (i) => _majorProfile[(i - r) % 12]);
    final rotMin = List<double>.generate(12, (i) => _minorProfile[(i - r) % 12]);
    final cMaj = _pearson(chroma, rotMaj);
    final cMin = _pearson(chroma, rotMin);
    if (cMaj > bestCorr) {
      bestCorr = cMaj;
      bestRoot = r;
      bestMinor = false;
    }
    if (cMin > bestCorr) {
      bestCorr = cMin;
      bestRoot = r;
      bestMinor = true;
    }
  }
  return _KeyResult(bestRoot, bestMinor, bestCorr);
}

const List<double> _bandEdges = [20, 60, 250, 500, 2000, 4000, 8000, 20000];

List<double>? _bandBalance(Int16List s) {
  const sr = 44100.0;
  const n = 4096;
  final fft = Fft(n);
  final win = _hann(n);
  final nframes = s.length ~/ n;
  final half = n ~/ 2;
  final p = Float64List(half + 1);
  final re = Float64List(n);
  final im = Float64List(n);
  var used = 0;
  for (var t = 0; t < nframes; t++) {
    final off = t * n;
    var sumSq = 0.0;
    for (var i = 0; i < n; i++) {
      final v = s[off + i] / 32768.0;
      sumSq += v * v;
    }
    if (math.sqrt(sumSq / n) < 1e-4) continue;
    for (var i = 0; i < n; i++) {
      re[i] = (s[off + i] / 32768.0) * win[i];
      im[i] = 0.0;
    }
    fft.transform(re, im);
    for (var k = 0; k <= half; k++) {
      p[k] += re[k] * re[k] + im[k] * im[k];
    }
    used++;
  }
  if (used == 0) return null;

  final bands = <double>[];
  var tot = 0.0;
  for (var i = 0; i < 7; i++) {
    final k0 = (_bandEdges[i] * n / sr).ceil();
    final k1 = (_bandEdges[i + 1] * n / sr).ceil();
    var sum = 0.0;
    for (var k = k0; k < k1 && k <= half; k++) {
      sum += p[k];
    }
    bands.add(sum);
    tot += sum;
  }
  if (tot <= 0) return null;
  return bands
      .map((b) => 10 * math.log(b / tot + 1e-20) / math.ln10)
      .toList();
}

/// Analiza muestras mono a 44.1 kHz (16 bits).
MusicAnalysis analyzeMusicSamples(Int16List samples) {
  final x11 = _downsample4(samples);
  final bpm = _detectBpm(x11);
  final key = _detectKey(x11);
  final bands = _bandBalance(samples);
  return MusicAnalysis(
    bpm: bpm?.bpm,
    bpmPeak: bpm?.peak ?? 0,
    keyRoot: key?.root,
    keyMinor: key?.minor ?? false,
    keyCorr: key?.corr ?? 0,
    bandsDb: bands,
  );
}

/// Lee un WAV mono 16 bits a 44.1 kHz y lo analiza. Corre dentro de un isolate.
Future<MusicAnalysis> analyzeMusicWav(String path) async {
  final bytes = await File(path).readAsBytes();
  var pos = 12;
  var dataStart = 44;
  var dataLen = bytes.length - 44;
  while (pos + 8 <= bytes.length) {
    final id = String.fromCharCodes(bytes.sublist(pos, pos + 4));
    final size =
        bytes[pos + 4] |
        (bytes[pos + 5] << 8) |
        (bytes[pos + 6] << 16) |
        (bytes[pos + 7] << 24);
    if (id == 'data') {
      dataStart = pos + 8;
      dataLen = math.min(size, bytes.length - dataStart);
      break;
    }
    pos += 8 + size + (size & 1);
  }
  final count = dataLen ~/ 2;
  final samples = Int16List(count);
  for (var i = 0; i < count; i++) {
    final lo = bytes[dataStart + 2 * i];
    final hi = bytes[dataStart + 2 * i + 1];
    var v = lo | (hi << 8);
    if (v >= 32768) v -= 65536;
    samples[i] = v;
  }
  return analyzeMusicSamples(samples);
}
